#include <stdio.h>
#include <iostream>
#include <cmath>

double f0(double x, double y);
double f1(double x, double y);
double f2(double x, double y);
double f3(double x, double y);
double f4(double x, double y);
double f5(double x, double y);
double f6(double x, double y);
double f7(double x, double y);
double max_matr(double *M, int nx, int ny);
double min_matr(double *M, int nx, int ny);
double max4(double a, double b, double c, double d);
double min4(double a, double b, double c, double d);
double max(double a, double b);
